
<?php $__env->startSection('title', 'Table Siswa'); ?>
<?php $__env->startSection('main'); ?>

    <div class="container-fluid mt-5">
        <ul class="nav nav-pills nav-secondary nav-pills-no-bd d-flex justify-content-center align-items-center mb-3"
            id="pills-tab-without-border" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="pills-all-tab-nobd" data-toggle="pill" href="#pills-all-nobd" role="tab"
                    aria-controls="pills-all-nobd" aria-selected="true">All</a>
            </li>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" id="pills-<?php echo e($item->id); ?>-tab-nobd" data-toggle="pill"
                        href="#pills-<?php echo e($item->id); ?>-nobd" role="tab" aria-controls="pills-<?php echo e($item->id); ?>-nobd"
                        aria-selected="true"><?php echo e($item->kelas); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="card border-0 shadow rounded">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">Data Siswa Ayodya</h4>
                </div>
            </div>
            <div class="card-body kekanan">
                <div class="tab-content mt-2 mb-3" id="pills-without-border-tabContent">
                    <div class="tab-pane fade show active" id="pills-all-nobd" role="tabpanel"
                        aria-labelledby="pills-all-tab-nobd">
                        <div class="mb-3 d-flex justify-content-between">
                            <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-md btn-success">Tambah Siswa</a>
                            <div>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">
                                    Import Excel
                                </button>
                            </div>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Import File</h5>
                                        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close">
                                            <i class="fa-solid fa-xmark"></i>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('file-import')); ?>" method="POST" enctype="multipart/form-data">
                                        <div class="modal-body">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group" style="max-width: 500px; margin: 0 auto;">
                                                <label for="">Donwload Template</label>
                                                <a href="<?php echo e(route('download.templates')); ?>" target="_blank"><button type="button" class="btn btn-info">Download</button></a>
                                            </div>
                                            <div class="form-group" style="max-width: 500px; margin: 0 auto;">
                                                <label for="">Kelas</label>
                                                <select class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="kelas">
                                                    <option value="">
                                                        <--- Pilih Kelas --->
                                                    </option>
                                                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->kelas); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group mb-4" style="max-width: 500px; margin: 0 auto;">
                                                <label for="">File Data Siswa ( Excel )</label>
                                                <input type="file" name="file" class="form-control">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                            <button class="btn btn-primary">Import data</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="multi-filter-select" class="display table table-striped table-hover">
                                <thead style="background: #7a74fc" class="text-white text-center">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Foto</th>
                                        <th scope="col">No Induk</th>
                                        <th scope="col">Nama Siswa</th>
                                        <th scope="col">Semester</th>
                                        <th scope="col">Cabang</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="text-center">
                                                <img src="<?php echo e(asset('/' . $siswa->foto)); ?>" alt="" width="80px">
                                            </td>
                                            <td><?php echo e($siswa->no_induk); ?></td>
                                            <td><?php echo e($siswa->nama_siswa); ?></td>
                                            <td><?php echo e($siswa->semester); ?></td>
                                            <td><?php echo e($siswa->tempat->name); ?></td>
                                            <td class="text-center">
                                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                                    action="<?php echo e(route('siswa.destroy', $siswa->id)); ?>" method="POST">
                                                    <a href="<?php echo e(route('siswa.show', $siswa->id)); ?>"
                                                        class="btn btn-success"><i class="fas fa-info-circle"></i></a>
                                                    <a href="<?php echo e(route('siswa.edit', $siswa->id)); ?>"
                                                        class="btn btn-primary"><i class="fas fa-edit"></i></a>

                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger"><i
                                                            class="fas fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade" id="pills-<?php echo e($item->id); ?>-nobd" role="tabpanel"
                            aria-labelledby="pills-<?php echo e($item->id); ?>-tab-nobd">
                            <div class="table-responsive">
                                <table class="siswa display table table-striped table-hover">
                                    <thead style="background: #7a74fc" class="text-white text-center">
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Foto</th>
                                            <th scope="col">No Induk</th>
                                            <th scope="col">Nama Siswa</th>
                                            <th scope="col">Semester</th>
                                            <th scope="col">Cabang</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sis->kelas == $item->id): ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td class="text-center">
                                                        <img src="<?php echo e(asset('/' . $sis->foto)); ?>" alt="" width="80px">
                                                    </td>
                                                    <td><?php echo e($sis->no_induk); ?></td>
                                                    <td><?php echo e($sis->nama_siswa); ?></td>
                                                    <td><?php echo e($sis->semester); ?></td>
                                                    <td><?php echo e($sis->tempat->name); ?></td>
                                                    <td class="text-center">
                                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                                            action="<?php echo e(route('siswa.destroy', $sis->id)); ?>"
                                                            method="POST">
                                                            <a href="<?php echo e(route('siswa.show', $sis->id)); ?>"
                                                                class="btn btn-success"><i
                                                                    class="fas fa-info-circle"></i></a>
                                                            <a href="<?php echo e(route('siswa.edit', $sis->id)); ?>"
                                                                class="btn btn-primary"><i class="fas fa-edit"></i></a>

                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><i
                                                                    class="fas fa-trash"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jquery'); ?>
    <script>
        $(document).ready(function() {
            $('.siswa').DataTable({
                "pageLength": 5,
                initComplete: function() {
                    this.api().columns().every(function() {
                        var column = this;
                        var select = $(
                                '<select class="form-control"><option value=""></option></select>'
                            )
                            .appendTo($(column.footer()).empty())
                            .on('change', function() {
                                var val = $.fn.dataTable.util.escapeRegex(
                                    $(this).val()
                                );

                                column
                                    .search(val ? '^' + val + '$' : '', true, false)
                                    .draw();
                            });

                        column.data().unique().sort().each(function(d, j) {
                            select.append('<option value="' + d + '">' + d +
                                '</option>')
                        });
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/user/siswa/index.blade.php ENDPATH**/ ?>