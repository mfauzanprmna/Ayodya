
<?php $__env->startSection('title', 'Layout'); ?>
<?php $__env->startSection('main'); ?>
    <div class="card-body">
        <ul class="nav nav-pills nav-secondary nav-pills-no-bd d-flex justify-content-center align-items-center"
            id="pills-tab-without-border" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="pills-home-tab-nobd" data-toggle="pill" href="#background" role="tab"
                    aria-controls="pills-home-nobd" aria-selected="true">Background</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="pills-home-tab-nobd" data-toggle="pill" href="#layout" role="tab"
                    aria-controls="pills-layout-nobd" aria-selected="true">Layout</a>
            </li>
        </ul>
        <div class="tab-content mt-2 mb-3" id="pills-without-border-tabContent">
            <div class="tab-pane fade show active" id="background" role="tabpanel" aria-labelledby="pills-home-tab-nobd">
                <div class="container-fluid">
                    <div class="card border-0 shadow rounded">
                        <div class="card-body kekanan">
                            <a href="<?php echo e(route('layout.create')); ?>" class="btn btn-md btn-success mb-3">Tambah
                                Background</a>
                            <div class="table-responsive">
                                <table id="multi-filter-select" class="display table table-striped table-hover">
                                    <thead style="background: #7a74fc" class="text-white text-center">
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Background</th>
                                            <th scope="col">Kelas</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-center">
                                        <?php $__currentLoopData = $layouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td style="width: 50%">
                                                    <img src="<?php echo e(asset('/') . $layout->image); ?>" alt="" width="50%">
                                                </td>
                                                <td><?php echo e($layout->kelas); ?></td>
                                                <td class="text-center">
                                                    <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                                        action="<?php echo e(route('layout.destroy', $layout->id)); ?>" method="POST">
                                                        <a href="<?php echo e(route('layout.edit', $layout->id)); ?>"
                                                            class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger"><i
                                                                class="fas fa-trash"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade show" id="layout" role="tabpanel" aria-labelledby="pills-layout-tab-nobd">
                <div class="container-fluid">
                    <div class="card border-0 shadow rounded">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Data Sertifikat</h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('layout.serti')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label class="font-weight-bold">Tanggal Pengambilan Nilai</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tanggal" id="" value="<?php echo e(old('tanggal', $text->tanggal)); ?>">

                                    <!-- error message untuk kelas -->
                                    <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mt-2">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label class="font-weight-bold">Tempat Pengambilan Nilai</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tanggal" id="" value="<?php echo e($text->tempat); ?>">

                                    <!-- error message untuk kelas -->
                                    <?php $__errorArgs = ['tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mt-2">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <button type="submit" class="btn btn-md btn-primary">Simpan</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/layout/index.blade.php ENDPATH**/ ?>