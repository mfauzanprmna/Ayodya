
<?php $__env->startSection('main'); ?>
    <div class="container-fluid mt-5">
        <div class="card border-0 shadow rounded">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">Data Nilai Tari</h4>
                </div>
            </div>
            <div class="card-body kekanan">
                
                <div class="mb-3 d-flex justify-content-between">
                    <a href="<?php echo e(route('nilai.create')); ?>" class="btn btn-md btn-success">Tambah Nilai Tari</a>
                    <div>
                        <a href="<?php echo e(route('nilai_export')); ?>">
                            <button type="button" class="btn btn-primary">
                                Export Excel
                            </button>
                        </a>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Import Excel
                        </button>
                    </div>
                </div>
                <div class="table-responsive">
                    <?php echo $__env->make('nilai.tari.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/nilai/tari/index.blade.php ENDPATH**/ ?>