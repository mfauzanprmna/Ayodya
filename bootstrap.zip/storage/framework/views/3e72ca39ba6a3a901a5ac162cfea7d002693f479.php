
<?php $__env->startSection('main'); ?>
    <div class="container-fluid mt-5">
        <ul class="nav nav-pills nav-secondary nav-pills-no-bd d-flex justify-content-center align-items-center mb-3"
            id="pills-tab-without-border" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="pills-all-tab-nobd" data-toggle="pill" href="#pills-all-nobd" role="tab"
                    aria-controls="pills-all-nobd" aria-selected="true">All</a>
            </li>
            <?php $__currentLoopData = $juri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" id="pills-<?php echo e($item->id); ?>-tab-nobd" data-toggle="pill"
                        href="#pills-<?php echo e($item->id); ?>-nobd" role="tab" aria-controls="pills-<?php echo e($item->id); ?>-nobd"
                        aria-selected="true"><?php echo e($item->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="card border-0 shadow rounded">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">Data Nilai Sinopsis</h4>
                </div>
            </div>
            <div class="card-body kekanan">
                <div class="tab-content mt-2 mb-3" id="pills-without-border-tabContent">
                    <div class="tab-pane fade show active" id="pills-all-nobd" role="tabpanel"
                        aria-labelledby="pills-all-tab-nobd">
                        <div class="mb-3 d-flex justify-content-between">
                            <a href="<?php echo e(route('sinopsis.create')); ?>" class="btn btn-md btn-success">Tambah Nilai
                                Sinopsis</a>
                            <div>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">
                                    Export Excel
                                </button>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">
                                    Import Excel
                                </button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="multi-filter-select" class="display table table-striped table-hover">
                                <thead style="background: #7a74fc" class="text-white text-center">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama Siswa</th>
                                        <th scope="col">Semester</th>
                                        <th scope="col">Nilai</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $sinopsis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($nilai->siswa->nama_siswa); ?></td>
                                            <td><?php echo e($nilai->semester); ?></td>
                                            <td><?php echo e($nilai->nilai); ?></td>
                                            <td class="text-center">
                                                <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                                    action="<?php echo e(route('sinopsis.destroy', $nilai->id)); ?>" method="POST">
                                                    <a href="<?php echo e(route('sinopsis.edit', $nilai->id)); ?>"
                                                        class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php $__currentLoopData = $juri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade" id="pills-<?php echo e($item->id); ?>-nobd" role="tabpanel"
                            aria-labelledby="pills-<?php echo e($item->id); ?>-tab-nobd">
                            <div class="table-responsive">
                                <table id="multi-filter-select" class="display table table-striped table-hover">
                                    <thead style="background: #7a74fc" class="text-white text-center">
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Nama Siswa</th>
                                            <th scope="col">Semester</th>
                                            <th scope="col">Nilai</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sinopsis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($nilai->id_juri == $item->id): ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($nilai->siswa->nama_siswa); ?></td>
                                                    <td><?php echo e($nilai->semester); ?></td>
                                                    <td><?php echo e($nilai->nilai); ?></td>
                                                    <td class="text-center">
                                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                                            action="<?php echo e(route('sinopsis.destroy', $nilai->id)); ?>"
                                                            method="POST">
                                                            <a href="<?php echo e(route('sinopsis.edit', $nilai->id)); ?>"
                                                                class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/nilai/sinopsis/index.blade.php ENDPATH**/ ?>