
<?php $__env->startSection('title', 'Create Background'); ?>
<?php $__env->startSection('main'); ?>

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h4 class="card-title">Tambah Data Background</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('layout.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label class="">Upload Image <span class="required-label">*</span></label>
                                <div class="">
                                    <div class="input-file input-file-image">
                                        <img class="img-upload-preview" width="140" height="100"
                                            src="http://placehold.it/140x100" alt="preview">
                                        <input type="file" class="form-control form-control-file" id="uploadImg"
                                            name="background" accept="image/*" required>
                                        <label for="uploadImg" class="btn btn-primary btn-round btn-lg"><i
                                                class="fa fa-file-image"></i> Upload a Image</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">Kelas</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="kelas" value="<?php echo e(old('kelas')); ?>" placeholder="Masukkan Kelas">

                                <!-- error message untuk kelas -->
                                <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-md btn-primary">Simpan</button>
                            <a href="<?php echo e(route('layout.index')); ?>">
                                <button type="reset" class="btn btn-md btn-warning">Kembali</button>
                            </a>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/layout/create.blade.php ENDPATH**/ ?>