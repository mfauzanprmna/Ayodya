
<?php $__env->startSection('title', 'Table Cabang'); ?>
<?php $__env->startSection('main'); ?>
    <div class="container-fluid mt-5">
        <div class="card border-0 shadow rounded">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">Data Cabang Ayodya</h4>
                </div>
            </div>
            <div class="card-body kekanan">
                <a href="<?php echo e(route('cabang.create')); ?>" class="btn btn-md btn-success mb-3">Tambah Cabang</a>
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover">
                        <thead style="background: #7a74fc" class="text-white text-center">
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Id Cabang</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Foto</th>
                                <th scope="col">Email</th>
                                <th scope="col">Aksi</th>

                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($cab->singkatan); ?></td>
                                    <td><?php echo e($cab->name); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('/' . $cab->foto)); ?>" alt="" width="80px">
                                    </td>
                                    <td><?php echo e($cab->email); ?></td>
                                    <td class="text-center">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                            action="<?php echo e(route('cabang.destroy', $cab->id)); ?>" method="POST">
                                            <a href="<?php echo e(route('cabang.edit', $cab->id)); ?>" class="btn btn-primary"><i
                                                    class="fas fa-edit"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"><i
                                                    class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/user/cabang/index.blade.php ENDPATH**/ ?>