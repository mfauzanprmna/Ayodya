<table id="multi-filter-select" class="display table table-striped table-hover">
    <thead style="background: #7a74fc" class="text-white text-center">
        <?php if(request()->is('nilai_export')): ?>
            <tr>
                <th colspan="6" style="text-align: center">Data Nilai Tari Siswa Ayodya Pala</th>
            </tr>
        <?php endif; ?>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Siswa</th>
            <th scope="col">Jenis Tari</th>
            <th scope="col">Wirama</th>
            <th scope="col">Wiraga</th>
            <th scope="col">Wirasa</th>
            <?php if(request()->is('admin/nilai')): ?>
                <th scope="col">Aksi</th>
            <?php endif; ?>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $nilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($nilai->siswa->nama_siswa); ?></td>
                <td><?php echo e($nilai->tari->nama); ?></td>
                <td><?php echo e($nilai->wirama); ?></td>
                <td><?php echo e($nilai->wiraga); ?></td>
                <td><?php echo e($nilai->wirasa); ?></td>
                <?php if(request()->is('admin/nilai')): ?>
                    <td class="text-center">
                        <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                            action="<?php echo e(route('nilai.destroy', $nilai->id)); ?>" method="POST">
                            <a href="<?php echo e(route('nilai.edit', $nilai->id)); ?>" class="btn btn-primary"><i
                                    class="fas fa-edit"></i></a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\Ayodya\resources\views/nilai/tari/table.blade.php ENDPATH**/ ?>